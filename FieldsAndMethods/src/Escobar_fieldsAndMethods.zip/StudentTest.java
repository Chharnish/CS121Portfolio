public class StudentTest {
    public static void main(String[] args) {
        Student Jeremy = new Student("Jeremy", "First", "Computer Science", 20, 3.3);
        Jeremy.printData();
    }
}
