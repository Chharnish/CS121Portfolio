import java.util.ArrayList;
public class StudentRecord {
    private ArrayList<Student> students = new ArrayList<>();
    //methods
    public void addStudent(Student student) {
        students.add(student);
    }
    public void removeStudent(Student student){
        students.remove(student);
    }
    public ArrayList<Student> getStudentArrayList() {
        return students;
    }

    public Student getStudent(String studentName) {
        Student foundStudent = null;
        for (Student student : students) {
            if (student.getName().equals(studentName)) {
                foundStudent = student;
                break;
            }
        }
        return foundStudent;
    }
    public StringBuilder getAllStudents() {
        StringBuilder allStudents = new StringBuilder();
        for (Student student : students){
            allStudents.append(student);
        }
        return allStudents;
    }
}
