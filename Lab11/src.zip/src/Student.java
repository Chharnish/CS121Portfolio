import java.util.ArrayList;
public class Student {
    private String name;
    private Double GPA;
    private ArrayList<Course> coursesArrayList = new ArrayList<>();

    //constructor
    public Student(String name, Double GPA){
        this.name = name;
        this.GPA = GPA;
    }
    //getters & setters
    public String getName() {
        return name;
    }
    public Double getGPA() {
        return GPA;
    }
    public ArrayList<Course> getCoursesArrayList(){
        return coursesArrayList;
    }

    public void addCourse(Course course){
        coursesArrayList.add(course);
    }
    public void remCourse(Course course){
        coursesArrayList.remove(course);
    }

    public Course getCourse(String courseName){
        Course foundCourse = null;
        for (Course course: coursesArrayList){
            if (course.getCourse().equals(courseName)){
                foundCourse = course;
                break;
            }
        }
        return foundCourse;
    }
    public StringBuilder displayCourseList() {
        StringBuilder courses = new StringBuilder();
        for (Course course : coursesArrayList){
            courses.append(course + "\n");
        }
        return courses;
    }

    @Override
    public String toString(){
        return String.format("%s \nGPA: %s", name, GPA);
    }
}
